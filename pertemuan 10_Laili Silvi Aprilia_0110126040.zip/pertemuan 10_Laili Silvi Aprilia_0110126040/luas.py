import math

# Function luas lingkaran
def luas_lingkaran(bil1, bil2):
    hasil = math.pi * bil1 * bil1
    print("Hasil luas lingkaran =", hasil)


# Function luas segitiga
def luas_segitiga(bil1, bil2):
    hasil = 0.5 * bil1 * bil2
    print("Hasil luas segitiga =", hasil)


# Function luas persegi
def luas_persegi(bil1, bil2):
    hasil = bil1 * bil1
    print("Hasil luas persegi =", hasil)
