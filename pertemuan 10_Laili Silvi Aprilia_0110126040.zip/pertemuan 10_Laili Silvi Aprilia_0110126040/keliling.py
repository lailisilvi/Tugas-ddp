import math

# Function keliling lingkaran
def keliling_lingkaran(bil1, bil2):
    hasil = 2 * math.pi * bil1
    print("Hasil keliling lingkaran =", hasil)


# Function keliling segitiga
def keliling_segitiga(bil1, bil2):
    hasil = bil1 + (2 * bil2)
    print("Hasil keliling segitiga =", hasil)


# Function keliling persegi
def keliling_persegi(bil1, bil2):
    hasil = 4 * bil1
    print("Hasil keliling persegi =", hasil)
