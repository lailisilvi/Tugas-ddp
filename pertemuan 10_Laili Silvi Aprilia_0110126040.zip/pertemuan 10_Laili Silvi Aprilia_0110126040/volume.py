import math

# Function volume kubus
def volume_kubus(bil1, bil2):
    hasil = bil1 * bil1 * bil1
    print("Hasil volume kubus =", hasil)


# Function volume tabung
def volume_tabung(bil1, bil2):
    hasil = math.pi * bil1 * bil1 * bil2
    print("Hasil volume tabung =", hasil)


# Function volume bola
def volume_bola(bil1, bil2):
    hasil = (4/3) * math.pi * bil1 * bil1 * bil1
    print("Hasil volume bola =", hasil)