print("")
print("PROGRAM BANGUN DATAR")
print("DAN BANGUN RUANG")
print("")

# Menggunakan modul
import luas
import keliling
import volume

print("\nMENU UTAMA")
print("1. Menghitung Luas Bangun Datar")
print("2. Menghitung Keliling Bangun Datar")
print("3. Menghitung Volume Bangun Ruang")

pilihan = int(input("Masukkan pilihan: "))


# MENU LUAS
if pilihan == 1:

    print("\nMENU LUAS")
    print("1. Lingkaran")
    print("2. Segitiga")
    print("3. Persegi")

    pilihan2 = int(input("Pilih bangun datar: "))

    bil1 = float(input("Masukkan bilangan 1: "))
    bil2 = float(input("Masukkan bilangan 2 (isi 0 jika tidak digunakan): "))

    if pilihan2 == 1:
        luas.luas_lingkaran(bil1, bil2)

    elif pilihan2 == 2:
        luas.luas_segitiga(bil1, bil2)

    elif pilihan2 == 3:
        luas.luas_persegi(bil1, bil2)

    else:
        print("Pilihan tidak tersedia")


# MENU KELILING
elif pilihan == 2:

    print("\nMENU KELILING")
    print("1. Lingkaran")
    print("2. Segitiga Sama Kaki")
    print("3. Persegi")

    pilihan2 = int(input("Pilih bangun datar: "))

    bil1 = float(input("Masukkan bilangan 1: "))
    bil2 = float(input("Masukkan bilangan 2: "))

    if pilihan2 == 1:
        keliling.keliling_lingkaran(bil1, bil2)

    elif pilihan2 == 2:
        keliling.keliling_segitiga(bil1, bil2)

    elif pilihan2 == 3:
        keliling.keliling_persegi(bil1, bil2)

    else:
        print("Pilihan tidak tersedia")


# MENU VOLUME
elif pilihan == 3:

    print("\nMENU VOLUME")
    print("1. Kubus")
    print("2. Tabung")
    print("3. Bola")

    pilihan2 = int(input("Pilih bangun ruang: "))

    bil1 = float(input("Masukkan bilangan 1: "))
    bil2 = float(input("Masukkan bilangan 2 (isi 0 jika tidak digunakan): "))

    if pilihan2 == 1:
        volume.volume_kubus(bil1, bil2)

    elif pilihan2 == 2:
        volume.volume_tabung(bil1, bil2)

    elif pilihan2 == 3:
        volume.volume_bola(bil1, bil2)

    else:
        print("Pilihan tidak tersedia")


else:
    print("Pilihan tidak tersedia")

print("\nPROGRAM SELESAI")